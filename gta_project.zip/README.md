Use this template for writing your course project report in Graph Theory and Application
1. Download using 
git clone https://github.com/anandmishra22/Template-for-GTA-course-Project.git

2. Use overleaf or latex commands to use.
